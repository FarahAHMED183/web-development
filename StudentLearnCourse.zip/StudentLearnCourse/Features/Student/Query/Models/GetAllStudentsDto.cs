namespace CRUD_Operation.Features.Student.Query.Models
{
    public class GetAllStudentsDto : IRequest<Response>
    {
    }
}
