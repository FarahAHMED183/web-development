namespace CRUD_Operation.Features.Learn.Query.Models
{
    public class GetAllEnrollmentsDto : IRequest<Response>
    {
    }
}
