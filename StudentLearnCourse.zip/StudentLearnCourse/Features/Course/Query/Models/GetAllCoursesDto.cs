namespace CRUD_Operation.Features.Course.Query.Models
{
    public class GetAllCoursesDto : IRequest<Response>
    {
    }
}
