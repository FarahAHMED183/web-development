namespace CRUD_Operation.AppMetaData.BaseRouter
{
    public partial class Router
    {
        private const string root = "Api";
        private const string version = "V1";
        public const string Rule = root + "/" + version + "/";
    }
}
